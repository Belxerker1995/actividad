class UsermailerMailer < ApplicationMailer
end
