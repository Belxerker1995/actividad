class Usermail < ApplicationRecord
end
