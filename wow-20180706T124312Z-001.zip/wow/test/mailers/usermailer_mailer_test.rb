require 'test_helper'

class UsermailerMailerTest < ActionMailer::TestCase
  # test "the truth" do
  #   assert true
  # end
end
