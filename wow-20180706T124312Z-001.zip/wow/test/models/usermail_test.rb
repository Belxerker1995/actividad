require 'test_helper'

class UsermailTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
