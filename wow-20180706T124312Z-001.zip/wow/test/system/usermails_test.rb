require "application_system_test_case"

class UsermailsTest < ApplicationSystemTestCase
  setup do
    @usermail = usermails(:one)
  end

  test "visiting the index" do
    visit usermails_url
    assert_selector "h1", text: "Usermails"
  end

  test "creating a Usermail" do
    visit usermails_url
    click_on "New Usermail"

    fill_in "Email", with: @usermail.email
    fill_in "Login", with: @usermail.login
    fill_in "Name", with: @usermail.name
    click_on "Create Usermail"

    assert_text "Usermail was successfully created"
    click_on "Back"
  end

  test "updating a Usermail" do
    visit usermails_url
    click_on "Edit", match: :first

    fill_in "Email", with: @usermail.email
    fill_in "Login", with: @usermail.login
    fill_in "Name", with: @usermail.name
    click_on "Update Usermail"

    assert_text "Usermail was successfully updated"
    click_on "Back"
  end

  test "destroying a Usermail" do
    visit usermails_url
    page.accept_confirm do
      click_on "Destroy", match: :first
    end

    assert_text "Usermail was successfully destroyed"
  end
end
